"""Py test that does a test function"""
from __future__ import division, with_statement, print_function
import usertest
# import os
# import time
# import subprocess

# Test Serial IO of DUT
# Monitor DUT Serial IO with Promira Serial Platform
# Articulate DUT with Nucleo64.ate
# DUT Specified as Nucleo64.dut

# DUT Interface
# 2 GPIO Output
#   1 Bit: DUT Select
#
# 2 GPIO Input
# 	1 Bit: DUT Busy
#   1 Bit: DUT ReadDataRdy
# 	1 Bit: DUT WriteDataRdy
#
# 8 bits command register
# COMMANDS:
#     INIT
# 		DUT transition to initial/ready state
#
#     START
# 		DUT transiton to execute tests state
#
#     CONTINUE
# 		DUT transition to execute next subtest
#
# 	DUT Behavior
# 		DUT initialized
# 		At start of each test, DUT performs test function read cycle
# 		DUT then performs the testfunction specified by contents
# 		of the command register
#     
#
# 	Manifest of tests
# 	- basic SIO tests
#   - parameter setting for SIO Output Corruption/Dropout
#         this helps verify PROMIRA Platform failure detection
# 
# 		1. I2C Write Packet
# 		2. I2C Read Packet
# 		3. I2C Repeat Write Packet
# 		4. I2C Repeat Read Packet
# 		5. I2C Set Corruption Modulus
# 		6. I2C Set Char Dropout Modulus
# 		7. I2C Set Packet Dropout Modulus
#

#==========================================================================
# IMPORTS
#==========================================================================

import array
import sys

import aa_pm_py as promira
# from smtpd import program

import time
import random
#from __builtin__ import None
import collections


#==========================================================================
# CONSTANTS
#==========================================================================
BUFFER_SIZE = 65535
SLAVE_RESP_SIZE = 5  # 26
INTERVAL_TIMEOUT = 500

#==========================================================================
# FUNCTIONS
#==========================================================================


# SPI COMMANDS
# CMD LIST: [ [ CMD_LENGTH, DATA_TRANSFER_TYPE, DATA_ARRAY_LENGTH ], [CMD_BYTES]]
# 
#





class promiraTestApp(usertest.SwUserTest):
  """Unit test template"""
  BUSTYPE_UNKNOWN=0
  BUSTYPE_I2C=1
  BUSTYPE_SPI=2
  
  m_bus_type=BUSTYPE_UNKNOWN

  m_pkgsize = 32
  m_rxdata_array = promira.array_u08(m_pkgsize)
  m_txdata_array = promira.array_u08(m_pkgsize)
  
  m_slaveAddress = 0x55
  m_Aardvark = 0
  m_device = m_slaveAddress
  m_bitrate_khz = 400
  m_devices = promira.array_u16(4)
  m_device_ids = promira.array_u32(4)
  m_device_ips = promira.array_u32(4)
  m_device_status = promira.array_u32(4)
  m_randarray_count=32
  m_random_arrays = []

  m_spi_bitrate_khz=125

  EEPROM_SIZE=0x400000
  KB8=0x2000
  KB32=0x8000
  KB64=0x10000
  # 4 8KB BLOCKS FROM ADDRESS 0
  # 1 32KB BLOCKS FROM ADDRESS 0x8000
  # 32 64KB BLOCKS FROM ADDRESS 0x10000
  # 1 32BLOCK FROM ADDRESS 0x3F0000
  # 4 8KB BLOCKS FROM ADDRESS 0x3F8000
  
  MEM_ADDRESS=0
  MEM_BLOCKSIZE=1
  MEM_BLOCKCOUNT=2
  
  EEPROM_BLOCKS=[[0x0, KB8, 4],
                 [0x8000, KB32, 1],
                 [0x10000, KB64, 31],
                 [0x3F0000, KB32, 1],
                 [0x3F8000, KB8, 4],
                 [0x400000, 0, 0]]
  
  ENUMERATED_BLOCKS=[]
  
  def __init__(self):
    self.enumerate_blocks()

  def enumerate_blocks(self):
    for blockset in self.EEPROM_BLOCKS:
      address=blockset[0]
      if address==self.EEPROM_SIZE:
        break;
      blocksize=blockset[1]
      blockcount=blockset[2]
      enumeration_address=address
      
      for index in range(blockcount):
        self.ENUMERATED_BLOCKS.append([enumeration_address, blocksize])
        enumeration_address+=blocksize
        pass
      pass
    return
  
  # SPISPEC ENTRIES
  SPISPEC_CMDBYTE=0
  SPISPEC_MODE_IDS=1
  
  SPISPEC_MODES_SUBITEM=2
  SPISPEC_XFERARRAY=2

#  SPISPEC_LENITEM=1
  SPISPEC_XFERTYPE_SUBITEM=0
  SPISPEC_XFERLEN_SUBITEM=1

  # SPIMODE_
  # [SPIMODES, ADDRCY, DUMMYCY, DATACY]
  MODE_ID=0
  MODE_ADDRCY=1
  MODE_DUMMYCY=2
  MODE_DATACY=3
  
  MODE_SPI=1
  MODE_SQI=2
  MODE_SXI=3
  SPIMODE_MODEITEM=0
  SPIMODE_ADDRCY_ITEM=1
  SPIMODE_DUMMYCY_ITEM=2
  SPIMODE_DATACY_ITEM=3
  
  ADCY_0=0
  ADCY_1=1
  ADCY_2=2
  ADCY_3=3
  DCY_0=0
  DCY_1=1
  DCY_2=2
  DCY_1_INF=0x8001
  DCY_2_INF=0x8002
  DCY_3_INF=0x8003
  DCY_1_X100=0x0103
  DCY_N_INF=0xFFFF
  DMY_0=0
  DMY_1=1
  DMY_2=2
  DMY_3=3

  SPISPEC_XFERTYPE_OUTPUT=1
  SPISPEC_XFERTYPE_INPUT=2
  SPISPEC_XFERTYPE_NONE=0
  
  SPIMODE_0=[ MODE_SXI, ADCY_0, DMY_0, DCY_0]
  SPIMODE_1=[ MODE_SPI, ADCY_0, DMY_0, DCY_0]
  SPIMODE_2=[ MODE_SPI, ADCY_0, DMY_0, DCY_1_INF]
  SPIMODE_3=[ MODE_SQI, ADCY_0, DMY_1, DCY_1_INF]
  SPIMODE_4=[ MODE_SXI, ADCY_0, DMY_0, DCY_2]
  SPIMODE_5=[ MODE_SPI, ADCY_3, DMY_0, DCY_1_INF]
  SPIMODE_6=[ MODE_SQI, ADCY_3, DMY_3, DCY_1_INF]
  SPIMODE_7=[ MODE_SPI, ADCY_3, DMY_1, DCY_1_INF]
  SPIMODE_8=[ MODE_SXI, ADCY_0, DMY_0, DCY_1]
  SPIMODE_9=[ MODE_SQI, ADCY_3, DMY_3, DCY_N_INF]
  SPIMODE_A=[ MODE_SPI, ADCY_3, DMY_3, DCY_N_INF]
  SPIMODE_B=[ MODE_SPI, ADCY_0, DMY_0, DCY_3_INF]
  SPIMODE_C=[ MODE_SQI, ADCY_0, DMY_1, DCY_3_INF]
  SPIMODE_D=[ MODE_SQI, ADCY_3, DMY_1, DCY_1_INF]
  SPIMODE_E=[ MODE_SXI, ADCY_3, DMY_0, DCY_0]
  
  NOP=0x00
  RSTEN=0x66
  RSTMEM=0x99
  ENQIO=0x38
  RSTQIO=0xFF
  RDSR=0x05
  WRSR=0x01
  RDCR=0x35
  READ=0x03
  HSREAD=0x0B
  SQOREAD=0x6B
  SQIOREAD=0xEB
  SDOREAD=0x3B
  SDIOREAD=0xBB
  SETBURST=0xC0
  RBSQI_WRAP=0x0C
  RBSPI_WRAP=0xEC
  JEDEC_ID=0x9F
  QUAD_JID=0xAF
  SFDP=0x5A
  WREN=0x06
  WRDI=0x04
  SE=0x20
  BE=0xD8
  CE=0xC7
  PP=0x02
  QPP=0x32
  
  READ_DATA_CMDS=[RDSR, RDCR, READ, HSREAD, SQOREAD,SQIOREAD, SDOREAD, SDIOREAD, RBSQI_WRAP, RBSPI_WRAP, JEDEC_ID, QUAD_JID, SFDP ]
  WRITE_DATA_CMDS=[WRSR, SETBURST, PP, QPP ]
  NODATA_CMDS=[NOP, RSTEN, RSTMEM, ENQIO, RSTQIO, WREN, WRDI, SE, BE, CE ]
  
  SPICMD_NOP=[0x00, 0]
  SPICMD_RSTEN=[0x66, 0]
  SPICMD_RSTMEM=[0x99, 0]
  SPICMD_ENQIO=[0x38, 1]
  SPICMD_RSTQIO=[0xFF, 0]
  SPICMD_RDSR=[0x05, [2,3]]
  SPICMD_WRSR=[0x01, 4]
  SPICMD_RDCR=[0x35, [2,3]]
  SPICMD_READ=[0x03, 5]
  SPICMD_HSREAD=[0x0B, [6,7]]
  SPICMD_SQOREAD=[0x6B, 7]
  SPICMD_SQIOREAD=[0xEB, 6]
  SPICMD_SDOREAD=[0x3B, 7]
  SPICMD_SDIOREAD=[0xBB, 7]
  SPICMD_SETBURST=[0xC0, 8]
  SPICMD_RBSQI_WRAP=[0x0C,9]
  SPICMD_RBSPI_WRAP=[0xEC,0x0A]
  SPICMD_JEDEC_ID=[0x9F,0x0B]
  SPICMD_QUAD_JID=[0xAF,0x0C]
  SPICMD_SFDP=[0x5A, 0x0D]
  SPICMD_WREN=[0x06, 0]
  SPICMD_WRDI=[0x04, 0]
  SPICMD_SE=[0x20, 0x0E]
  SPICMD_BE=[0xD8, 0x0E]
  SPICMD_CE=[0xC7, 0]
  SPICMD_PP=[0x02, 0x0F]
  SPICMD_QPP=[0x32, 0x0F]
  
  
  SPIMODE_0=promira.AA_SPI_PHASE_SAMPLE_SETUP+(promira.AA_SPI_SS_ACTIVE_LOW<<1)
  SPIMODE_1=promira.AA_SPI_PHASE_SAMPLE_SETUP+(promira.AA_SPI_SS_ACTIVE_HIGH<<1)
  SPIMODE_2=promira.AA_SPI_PHASE_SETUP_SAMPLE+(promira.AA_SPI_SS_ACTIVE_LOW<<1)
  SPIMODE_3=promira.AA_SPI_PHASE_SETUP_SAMPLE+(promira.AA_SPI_SS_ACTIVE_HIGH<<1)
  
  
  def cmdN64(self, command): 
      pass
  
  
  def spi_master_cmd (self, cmd_spec, xfer_bytescount=0, xfer_array=None):
    
    # SPI COMMAND MODE DATA HAS THESE ELEMENTS
    # SPI/SQI/SQX(BOTH) MODE
    # COUNT OF ADDRESS TRANSACTION CYCLES (ADDRESS BYTES WRITTEN TO DEVICE)
    # COUNT OF DUMMY TRANSACTION CYCLES (DON'T CARE BYTE WRITTEN TO DEVICE)
    # COUNT OF DATA TRANSACTION CYCLES (DATA EXCHANGED WITH DEVICE) ***
    # *** ON READ COMMANDS THE INCOMING DATA IS RELEVANT, OUTGOING IS DON'T CARE
    # *** ON WRITE COMMANDS THE OUTGOING DATA IS RELEVANT, INCOMING IS DON'T CARE
    # *** COMMANDS WHERE MEANINGFUL DATA IS OUTPUT *AND* INPUT IS POSSIBLE, BUT 
    #     NOT DEFINED FOR THIS EEPROM COMMAND SET


    mode_ids=cmd_spec[self.SPISPEC_MODE_IDS]
    if type(mode_ids) == list:
      for mode in mode_ids:
        if mode[self.MODE_ID] in [self.MODE_SPI, self.MODE_SXI]:
          addr_cycles=mode[self.MODE_ADDRCY]
          dummy_cycles=mode[self.MODE_DUMMYCY]
          data_cycles=mode[self.MODE_DATACY]
   
          if xfer_array!=None:
            send_data=len(xfer_array)
          else:
            send_data=0
            
          

          xfer_cycles=addr_cycles+dummy_cycles
        
        else:
          print("error: Quad Mode not supported")
          sys.exit()
        
      
    # Insure no bush-league errors in command specification    
    if  ( (xfer_length==0 and (xfer_array!=None or xfer_type!=self.SPISPEC_XFERTYPE_NONE)) 
          or (xfer_array==None and xfer_type==self.SPISPEC_XFERTYPE_OUTPUT)
          or (xfer_length>0 and xfer_array!=None and xfer_length!=len(xfer_array))
        ):
      print("spi_master_cmd_error: command specification error")
      exit(-1)
      
    
    # provide for input array when add_implicit_resolver
    data_in=promira.array_u08(xfer_length+1)
      
    # at this point:
    #   xfer_array is defined if we have data to send or receive after the command

    data_out=promira.array('B', cmd_spec[self.SPISPEC_CMDBYTE])
    if xfer_type==self.SPISPEC_XFERTYPE_OUTPUT:
      data_out+=xfer_array
    else:
      data_out+=data_in


    # Write length+3 bytes for data plus command and 2 address bytes
    (xfer_retcode, data_in) = promira.aa_spi_write(self.m_Aardvark, data_out, data_in)

    data_in=data_in[1:]
    if (len(data_in)!=xfer_length):
      print("spi_master_cmd_error: byte transfer count over/under-flow")
      exit(-1)
      
    return (len(data_in), data_in)
      
    
  def init_spi(self, port, bitrate):
    pass
  
  def init_spi_slave(self):
    pass


  def init_spi_master(self, port, bitrate, mode):
  # Open the device
    self.m_Aardvark = promira.aa_open(port)
    if (self.m_Aardvark <= 0):
        print("Unable to open Aardvark device on port %d" % self.m_device)
        print("Error code = %d" % self.m_Aardvark)
        sys.exit()

    # Ensure that the SPI subsystem is enabled
    promira.aa_configure(self.m_Aardvark,  promira.AA_CONFIG_SPI_I2C)
    
    # Power the EEPROM using the Aardvark adapter's power supply.
    # This command is only effective on v2.0 hardware or greater.
    # The power pins on the v1.02 hardware are not enabled by default.
    promira.aa_target_power(self.m_Aardvark, promira.AA_TARGET_POWER_TGT1_3V)
    
    # Setup the clock phase
    promira.aa_spi_configure(self.m_Aardvark, mode >> 1, mode & 1, promira.AA_SPI_BITORDER_MSB)
    
    # Set the bitrate
    bitrate = promira.aa_spi_bitrate(self.m_Aardvark, bitrate)
    print("Bitrate set to %d kHz" % bitrate)


    
  def close_session(self, handle):    
    # Close the device
    promira.aa_close(handle)
    
     
  def cmdPromira(self, command):
    pass
  
  
  
  def i2c_slave_read(self, maxcount, rxdata_array):
    promira.aa_i2c_slave_read(self.m_Aardvark, rxdata_array)
    pass
  
  def i2c_slave_write(self, count, txdata_array):
    pass
      
  def i2c_master_read(self, maxcount, rxdata_array):
      # prepare N64 to Read
      # command Promira to Write
      # get results
    (rx_count, rxdata_array) = promira.aa_i2c_read(self.m_Aardvark, self.m_device,
                                   promira.AA_I2C_NO_FLAGS, maxcount)    
    if (rx_count < 0):
        print("error: %s" % promira.aa_status_string(rx_count))

    elif (rx_count == 0):
        print("error: no bytes read")
        print("  are you sure you have the right slave address?")

    self.m_rxdata_array = rxdata_array
    return rx_count
  
  def i2c_master_write(self, txdata_count, txdata_array):
    
    count_txd = promira.aa_i2c_write(self.m_Aardvark, self.m_slaveAddress, promira.AA_I2C_NO_FLAGS, (txdata_array, txdata_count))

    if (count_txd < 0):
        print("error: %s" % promira.aa_status_string(count_txd))

    elif (count_txd == 0):
        print("error: no bytes written")
        print("  are you sure you have the right slave address?")

    elif (count_txd != len(txdata_array)):
        print("error: only a partial number of bytes written")
        print("  (%d) instead of full (%d)" % (count_txd, txdata_count))
    
    return(count_txd)
    
  def init_i2c(self, port, addr, timeout_ms):
    # Open the device
    self.m_Aardvark = promira.aa_open(port)
    if (self.m_Aardvark <= 0):
        print("Unable to open Aardvark device on port %d" % port)
        print("Error code = %d" % self.m_Aardvark_Aardvark)
        sys.exit()
    
    # Ensure that the I2C subsystem is enabled
    promira.aa_configure(self.m_Aardvark, promira.AA_CONFIG_SPI_I2C)
    
    # Enable the I2C bus pullup resistors (2.2k resistors).
    # This command is only effective on v2.0 hardware or greater.
    # The pullup resistors on the v1.02 hardware are enabled by default.
    promira.aa_i2c_pullup(self.m_Aardvark, promira.AA_I2C_PULLUP_BOTH)
    
    # Power the EEPROM using the Aardvark adapter's power supply.
    # This command is only effective on v2.0 hardware or greater.
    # The power pins on the v1.02 hardware are not enabled by default.
    promira.aa_target_power(self.m_Aardvark, promira.AA_TARGET_POWER_NONE)
    # Set the bitrate
    bitrate_khz = promira.aa_i2c_bitrate(self.m_Aardvark, self.m_bitrate_khz)
    print("Bitrate set to %d kHz" % bitrate_khz)
    pass
  
  def init_i2c_master(self):
    # hard code these in prototype
    # elegantly discover them in deliverable
    
    self.m_port = self.m_device_ips[0]  # default port for a single promira device
    self.m_slaveAddress = 0x55  # default for Arduino Nano TestSlave
    self.m_timeout_ms = 10000  # arbitrary 10 second value
    self.m_bitrate_khz = 400
    self.m_Aardvark = promira.aa_open(self.m_port)
    if (self.m_Aardvark <= 0):
        print("Unable to open Aardvark device on port %d" % self.m_port)
        print("Error code = %d" % self.m_Aardvark)
        sys.exit()
    
    # Set the slave response
    self.m_slave_resp_array = self.zeroed_u08_packet(self.m_pkgsize)

    promira.aa_i2c_slave_set_response(self.m_Aardvark, self.m_slave_resp_array)
    
    # Enable the slave
    promira.aa_i2c_slave_enable(self.m_Aardvark, self.m_slaveAddress, 0, 0)
    
    # Disable the slave and close the device
    promira.aa_i2c_slave_disable(self.m_Aardvark)
    promira.aa_close(self.m_Aardvark)
       
  def init_i2c_slave(self):
    # hard code these in prototype
    # elegantly discover them in deliverable
    
    # Open the device
    self.m_Aardvark = promira.aa_open(self.m_port)
    if (self.m_Aardvark <= 0):
        print("Unable to open Aardvark device on port %d" % self.m_port)
        print("Error code = %d" % self.m_Aardvark)
        sys.exit()
    
    # Set the slave response
    self.m_slave_resp = self.zeroed_u08_packet(self.m_pkgsize)

    promira.aa_i2c_slave_set_response(self.m_Aardvark, self.m_slave_resp)
    
    # Enable the slave
    promira.aa_i2c_slave_enable(self.m_Aardvark, self.m_slaveAddress, 0, 0)
    
    # Write to slave
    
    # Read from slave
    
    # Compare written to read data, show result
    
    # Disable the slave and close the device
    promira.aa_i2c_slave_disable(self.m_Aardvark)
    promira.aa_close(self.m_Aardvark)
  
  def zeroed_u08_packet(self, packet_size):
      base_array = promira.array_u08(packet_size)
      base_array[0] = packet_size - 1
      return base_array
  
  def random_u08_packet(self, packet_size):
      rand_array = self.zeroed_u08_packet(packet_size)
      for index in range(1, packet_size):
        rand_array[index] = random.randint(0, 255)
        
      return rand_array
    
  def build_random_arrays(self):
      for index in range(self.m_randarray_count):
          self.m_random_arrays.append(self.random_u08_packet(self.m_pkgsize))

  m_randarray_index=0
  
  def next_randarray(self):
      self.m_randarray_index=(self.m_randarray_index+1) % self.m_randarray_count
      return self.m_random_arrays[self.m_randarray_index]
    
  def runTest(self, busType):
    if busType in [self.BUSTYPE_I2C, self.BUSTYPE_SPI]:
      self.m_bus_type=busType
    else:
      print("error: illegal bus type")
      sys.exit()

    
    self.m_port = 0  # default port for a single promira device
    self.m_slaveAddress = 0x55  # default for Arduino Nano TestSlave
    self.m_timeout_ms = 1000  # arbitrary 10 second value 
    self.m_bitrate_khz = 400  # 100khz bus clock
    self.m_device = self.m_slaveAddress
    return_tuple = promira.aa_find_devices_pm(self.m_device_ips, self.m_device_ids, self.m_device_status)
    device_count = return_tuple[0]
    self.m_device_ips = return_tuple[1]
    self.m_devices = return_tuple[2]
    self.m_device_ids = return_tuple[3]
    print("device_count:" + str(device_count))

    random.seed(0)
    self.build_random_arrays()
    
    
    if self.m_bus_type==self.BUSTYPE_I2C:
      self.init_i2c_master()
      self.init_i2c(self.m_device_ips[0], 0, self.m_timeout_ms);
    else:
      self.m_bus_mode=self.SPIMODE_0
      self.init_spi_master(self.m_device_ips[0],  self.m_bitrate_khz, self.m_bus_mode )
      #self.init_spi(self.m_device_ips[0], self.m_bitrate_khz)
      
      
    self.m_txdata_array = self.random_u08_packet(self.m_pkgsize)
    txdata_count = self.m_pkgsize
    read_packets = True
    write_packets = True
    
    while True:
      if write_packets:
        self.m_txdata_array=self.next_randarray()
        
        if self.m_bus_type==self.BUSTYPE_I2C:
          writecount = self.i2c_master_write(txdata_count, self.m_txdata_array)
          if writecount < len(self.m_txdata_array):
            print ("Bad TxData Write %d instead of %d bytes", writecount, txdata_count)

          if read_packets:  
            readcount = self.i2c_master_read(txdata_count, self.m_rxdata_array)
            if readcount != txdata_count:
              print ("Bad RxData Read %d instead of %d bytes", readcount, txdata_count)
        
        if self.m_bus_type==self.BUSTYPE_SPI:
          (writecount, self.m_rxdata_array)=self.spi_master_cmd(self.SPICMD_READ_JEDEC)
          
        time.sleep(1)

#    self.run_test_core()  


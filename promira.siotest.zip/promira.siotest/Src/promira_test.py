from __future__ import division, with_statement, print_function
import TestDutSIO as dsio


######################################
dutSIO=dsio.promiraTestApp()

#run SPI Test
TEST_I2C_NOT_SPI=False

if (TEST_I2C_NOT_SPI):
  dutSIO.runTest(dutSIO.BUSTYPE_I2C)
else:
  dutSIO.runTest(dutSIO.BUSTYPE_SPI)
    